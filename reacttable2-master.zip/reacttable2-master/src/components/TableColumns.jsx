import React from "react";
import "../style.css"



const TableColumns = ({data}) => {
    // console.log("data=" , data);
    return (<>
        
        <table>
            <thead>
                <tr style={{background:"#00338D",color:"white"}}>
                    <th style={{}}>Columns</th>
                    
                </tr>
            </thead>
            <tbody>
                {data.map((item)=> (
                    <tr key = {item.id} style={{border:'3px solid white'}}>
                        <td> {item.Name}</td>
                        <td>{item.Type}</td>
                        <td>{item.Business_Name}</td>
                        <td>{item.Business_Description}</td>
                    
                    </tr>
                ))}
            </tbody>
        </table></>
    )
}
export default TableColumns;