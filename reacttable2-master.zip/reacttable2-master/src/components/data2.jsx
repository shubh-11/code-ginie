const data2 = [
        
            [
                {id : 1,Column_Name:"Table Name",Field:"HR_EMP"},
                {id : 2,Column_Name:"Source System",Field:"HRIS"},
                {id : 3,Column_Name:"Department",Field:"Human Resources"},
                {id : 4,Column_Name:"Business Name",Field:'1'},
                {id : 5,Column_Name:"Business Description",Field:'2'},
                {id : 6,Column_Name:"Contains PI",Field:'3'},
    ],
    [
        {id : 1,Column_Name:"Table Name",Field:"t_ORD"},
        {id : 2,Column_Name:"Source System",Field:"HRIS"},
        {id : 3,Column_Name:"Department",Field:"Human Resources"},
        {id : 4,Column_Name:"Business Name",Field:''},
        {id : 5,Column_Name:"Business Description",Field:''},
        {id : 6,Column_Name:"Contains PI",Field:' '},
],
[
    {Column_Name:"Table Name",Field:"T_ORD_ITEM"},
    {Column_Name:"Source System",Field:"HRIS"},
    {Column_Name:"Department",Field:"Human Resources"},
    {Column_Name:"Business Name",Field:''},
    {Column_Name:"Business Description",Field:''},
    {Column_Name:"Contains PI",Field:' '},
],
[
    {Column_Name:"Table Name",Field:"T_INV"},
    {Column_Name:"Source System",Field:"HRIS"},
    {Column_Name:"Department",Field:"Human Resources"},
    {Column_Name:"Business Name",Field:''},
    {Column_Name:"Business Description",Field:''},
    {Column_Name:"Contains PI",Field:' '},
],
[
    {Column_Name:"Table Name",Field:"HR_DEPT"},
    {Column_Name:"Source System",Field:"HRIS"},
    {Column_Name:"Department",Field:"Human Resources"},
    {Column_Name:"Business Name",Field:''},
    {Column_Name:"Business Description",Field:''},
    {Column_Name:"Contains PI",Field:' '},
],
[
    {Column_Name:"Table Name",Field:"HR_JOB"},
    {Column_Name:"Source System",Field:"HRIS"},
    {Column_Name:"Department",Field:"Human Resources"},
    {Column_Name:"Business Name",Field:''},
    {Column_Name:"Business Description",Field:''},
    {Column_Name:"Contains PI",Field:' '},
],
]
export default data2;