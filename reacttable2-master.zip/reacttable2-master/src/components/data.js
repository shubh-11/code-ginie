const data = [
    {id : 1,name: "T_ORD"},{id :2,name: "T_ORD_ITEM"},{ id:3,name: "HR_EMP"},{id:4,name:"T_INV"},{id:5,name:"HR_DEPT"},{id:6,name:"HR_JOB"}
];

export default data;